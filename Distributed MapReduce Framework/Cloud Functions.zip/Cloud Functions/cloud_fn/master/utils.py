
import os

import functions_framework
# from pymemcache.client import base
import redis

# client = base.Client(('10.80.112.3', 11211))
client = redis.Redis(host='10.113.32.235', port=6379, db=0)

@functions_framework.http
def hello_get(request):
    data = request.get_json()
    if data["ops"] == "SET":
        client.set(data["key"], data["val"])
        return "Successful"

    if data["ops"] == "GET":
        resp = client.get(data["key"])
        return str(resp)