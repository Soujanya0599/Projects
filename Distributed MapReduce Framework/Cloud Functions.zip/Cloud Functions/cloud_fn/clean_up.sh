#!/bin/bash
. ./ecc.config

for ((i=0; i < $MAPPERS; i++)); 
do
    echo "==== Deleting Cloud Function: mapper-$i ===="
    gcloud functions delete mapper-$i --region=${REGION} --project=${PROJECT_ID}  --quiet

done

for ((i=0; i < $REDUCERS; i++)); 
do
    echo "==== Deleting Cloud Function: reducer-$i ===="
    gcloud functions delete reducer-$i --region=${REGION} --project=${PROJECT_ID}  --quiet
done

echo "==== Deleting Cloud Function: Map Reduce Master ===="
gcloud functions delete master-http-function --region=${REGION} --project=${PROJECT_ID}  --quiet

echo "==== Deleting Streamin Data Indexing Function ===="
gcloud functions delete streaming-data-indexer --region=${REGION} --project=${PROJECT_ID}  --quiet

echo "Deleting frontend"
gcloud run services delete ecc-frontend --region=${REGION} --project=${PROJECT_ID} --quiet

echo "cleaning firestore.."
python3 clean_firestore.py pratheek-vadla-fall2022-firebase-adminsdk.json
echo "Deleted all collections in firestore."

echo "Deleting firewall rules.."
gcloud compute firewall-rules delete allow-all-ingress --project=${PROJECT_ID} --quiet

gcloud compute firewall-rules delete allow-all-ssh --project=${PROJECT_ID} --quiet

echo "Deleting Subnet.."
gcloud compute networks delete ${VPC_NAME} --project=${PROJECT_ID} --quiet

echo "===================================================="
echo "==================== FINISHED ======================"
echo "===================================================="