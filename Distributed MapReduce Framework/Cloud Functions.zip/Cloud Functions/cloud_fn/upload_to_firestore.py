import os
import argparse
from firebase_admin import credentials, firestore, initialize_app

parser = argparse.ArgumentParser()
parser.add_argument("--input_path", help="files to upload")
parser.add_argument("--collection", help="firestore collection")
parser.add_argument("--credentials", help="Firestore Credentials json")

args=parser.parse_args()
args = vars(args)

cred = credentials.Certificate(args["credentials"])
app = initialize_app(cred)

if __name__ == "__main__":

    collection = args["collection"]
    input_path = args["input_path"]
    db = firestore.client()
    for f_name in os.listdir(input_path):
        try:
            print(f"Uploading file: {f_name} to firestore...")
            doc_name = str(f_name.replace(".txt","").strip())
            doc_ref = db.collection(collection).document(doc_name)
            with open(f"{input_path}/{f_name}","r") as f:
                text = f.read()
                doc_ref.set({
                    'text':str(text),
                    'is_processed':False
                })
        except Exception as e:
            print(f"Failed to upload: {e}")