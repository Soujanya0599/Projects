#!/bin/bash
. ./ecc.config

echo "==== Uploading files to Google Fire Store ===="
python3 upload_to_firestore.py --input_path=${INPUT_DATA} --collection=${FIREBASE_COLLECTION} --credentials=${FIREBASE_CREDENTIALS}

for ((i=0; i < $MAPPERS; i++)); 
do
    echo "==== Deploying Cloud Function: mapper-$i ===="
    gcloud functions deploy mapper-$i --entry-point hello_firestore --runtime python310 --set-env-vars MAPPER_ID=mapper-$i --trigger-event "providers/cloud.firestore/eventTypes/document.create" --trigger-resource "projects/${PROJECT_ID}/databases/(default)/documents/mapper-$i/{docId}" --allow-unauthenticated --source=mapper/ --region=${REGION}

done

for ((i=0; i < $REDUCERS; i++)); 
do
    echo "==== Deploying Cloud Function: reducer-$i ===="
    gcloud functions deploy reducer-$i --entry-point hello_firestore --runtime python310 --set-env-vars REDUCER_ID=reducer-$i --trigger-event "providers/cloud.firestore/eventTypes/document.create" --trigger-resource "projects/${PROJECT_ID}/databases/(default)/documents/reducer-$i/{docId}" --allow-unauthenticated --source=reducer/ --region=${REGION}
done

echo "==== Deploying Cloud Function: Map Reduce Master ===="
gcloud functions deploy master-http-function --gen2 --runtime=python310 --region=${REGION} --source=master --entry-point=master --trigger-http --allow-unauthenticated --timeout=3600

echo "==== Deploying Streamin Data Indexing Function ===="
gcloud functions deploy streaming-data-indexer --entry-point hello_firestore --runtime python310 --trigger-event "providers/cloud.firestore/eventTypes/document.create" --trigger-resource "projects/${PROJECT_ID}/databases/(default)/documents/streaming-data/{docId}" --allow-unauthenticated --source=streaming_search/ --region=${REGION}

echo "==== Deploying Frontend using Google Cloud Run ===="
gcloud run deploy ecc-frontend --region=${REGION} --project=${PROJECT_ID} --set-env-vars UI_PORT=8080 --allow-unauthenticated --source ui/

echo "===== STARTING THE INDEXING JOB ====="
gcloud functions call master-http-function --data '{"mappers":2,"reducers":2,"firestore_collection":"'${FIREBASE_COLLECTION}'"}' --gen2 --region=${REGION}