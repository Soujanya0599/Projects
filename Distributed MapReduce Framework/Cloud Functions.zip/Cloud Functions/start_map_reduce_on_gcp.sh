#!/bin/bash
. ./ecc.config

echo "Creating VPC Network..."
gcloud compute networks create ${VPC_NAME} --project=${PROJECT_ID} --subnet-mode=auto --mtu=1460 --bgp-routing-mode=regional

echo "Applying Firewall Rules..."
gcloud compute firewall-rules create allow-all-ingress --project=${PROJECT_ID} --network=projects/${PROJECT_ID}/global/networks/${VPC_NAME} --description=allow_all. --direction=INGRESS --priority=65534 --source-ranges=0.0.0.0/0 --action=ALLOW --rules=all

gcloud compute firewall-rules create allow-all-ssh --project=${PROJECT_ID} --network=projects/${PROJECT_ID}/global/networks/${VPC_NAME} --description=tcp_port_22. --direction=INGRESS --priority=65534 --source-ranges=0.0.0.0/0 --action=ALLOW --rules=tcp:22

echo "====================================="
echo "===== Starting KV-Store Server ======"
echo "====================================="
gcloud compute instances create ${KV_SERVER} --project=${PROJECT_ID} --zone=${ZONE} --machine-type=${MACHINE_TYPE} --network-interface=network-tier=STANDARD,subnet=${VPC_NAME} --maintenance-policy=MIGRATE --provisioning-model=STANDARD --service-account=${SERVICE_ACCOUNT} --create-disk=auto-delete=yes,boot=yes,device-name=${KV_SERVER},image=projects/ubuntu-os-cloud/global/images/ubuntu-2204-jammy-v20221101a,mode=rw,size=10,type=projects/${PROJECT_ID}/zones/${ZONE}/diskTypes/pd-standard --no-shielded-secure-boot --no-shielded-vtpm --no-shielded-integrity-monitoring --reservation-affinity=any

sleep 30

kvstore_serverip=$(gcloud compute instances describe ${KV_SERVER} --format='get(networkInterfaces[0].networkIP)' --zone=${ZONE})

echo "====================================="
echo "== Transferring files to KV Server =="
echo "====================================="
gcloud compute scp --recurse kvstore_scripts/* ${KV_SERVER}:~ --project=${PROJECT_ID} --zone=${ZONE}

gcloud compute ssh ${KV_SERVER} --project=${PROJECT_ID} --zone=${ZONE}  --command "chmod +x *.sh" 

gcloud compute ssh ${KV_SERVER} --project=${PROJECT_ID} --zone=${ZONE}  --command "./bootstrap.sh -y"

echo "======================================"
echo "Starting KV Server With Native Backend"
echo "======================================"
gcloud compute ssh ${KV_SERVER} --project=${PROJECT_ID} --zone=${ZONE}  --command "nohup python3 kv_store.py --port=9979 > native.log 2>&1  </dev/null &"

sleep 2

echo "====================================="
echo "==== Starting Map Reduce Master ====="
echo "====================================="
gcloud compute instances create ${MR_MASTER} --project=${PROJECT_ID} --zone=${ZONE} --machine-type=${MACHINE_TYPE} --network-interface=network-tier=STANDARD,subnet=${VPC_NAME} --maintenance-policy=MIGRATE --provisioning-model=STANDARD --service-account=${SERVICE_ACCOUNT} --scopes=https://www.googleapis.com/auth/cloud-platform --create-disk=auto-delete=yes,boot=yes,device-name=${KV_CLIENT},image=projects/ubuntu-os-cloud/global/images/ubuntu-2204-jammy-v20221101a,mode=rw,size=10,type=projects/${PROJECT_ID}/zones/${ZONE}/diskTypes/pd-standard --no-shielded-secure-boot --no-shielded-vtpm --no-shielded-integrity-monitoring --reservation-affinity=any

sleep 30
echo "====================================="
echo "=== Transferring files to Master ===="
echo "====================================="

gcloud compute scp master_scripts/* ${MR_MASTER}:~ --project=${PROJECT_ID} --zone=${ZONE}

gcloud compute scp --recurse mapper_scripts ${MR_MASTER}:~ --project=${PROJECT_ID} --zone=${ZONE}

gcloud compute scp --recurse reducer_scripts ${MR_MASTER}:~ --project=${PROJECT_ID} --zone=${ZONE}

gcloud compute ssh ${MR_MASTER} --project=${PROJECT_ID} --zone=${ZONE}  --command "chmod +x *.sh"

gcloud compute ssh ${MR_MASTER} --project=${PROJECT_ID} --zone=${ZONE}  --command "./bootstrap.sh -y"

# gcloud compute ssh ${MR_MASTER} --project=${PROJECT_ID} --zone=${ZONE}  --command "nohup python3 master.py --kv_address=${kvstore_serverip} --kv_port=9979 --port=9986 --credentials=${CREDENTIALS} --project-id=${PROJECT_ID} --zone=${ZONE} > master.log 2>&1  </dev/null &"

gcloud compute ssh ${MR_MASTER} --project=${PROJECT_ID} --zone=${ZONE}  --command "python3 master.py --kv_address=${kvstore_serverip} --kv_port=9979 --port=9986 --credentials=${CREDENTIALS} --project_id=${PROJECT_ID} --zone=${ZONE}"

gcloud compute scp ${KV_SERVER}:~/reducer_output.txt . --project=${PROJECT_ID} --zone=${ZONE}

# echo "Terminating Instances.."
gcloud compute instances delete --quiet $(gcloud compute instances list | grep -v "NAME" | awk '{ print $1}') --zone=${ZONE}