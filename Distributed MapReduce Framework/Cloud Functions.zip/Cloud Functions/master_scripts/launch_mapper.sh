#!/bin/bash
. ./ecc.config

MAPPER_NODE=$1
MASTER_ADDR=$2
MASTER_PORT=$3
KV_ADDRESS=$4
KV_PORT=$5

echo "====================================="
echo "======= Starting Mapper Node ========"
echo "====================================="
gcloud compute instances create ${MAPPER_NODE} --project=${PROJECT_ID} --zone=${ZONE} --machine-type=${MACHINE_TYPE} --network-interface=network-tier=STANDARD,subnet=${VPC_NAME} --maintenance-policy=MIGRATE --provisioning-model=STANDARD --service-account=${SERVICE_ACCOUNT} --create-disk=auto-delete=yes,boot=yes,device-name=${MAPPER_NODE},image=projects/ubuntu-os-cloud/global/images/ubuntu-2204-jammy-v20221101a,mode=rw,size=10,type=projects/${PROJECT_ID}/zones/${ZONE}/diskTypes/pd-standard --no-shielded-secure-boot --no-shielded-vtpm --no-shielded-integrity-monitoring --reservation-affinity=any

sleep 30

echo "====================================="
echo "=== Transferring files to Mapper ===="
echo "====================================="

gcloud compute scp mapper_scripts/* ${MAPPER_NODE}:~ --project=${PROJECT_ID} --zone=${ZONE} --ssh-key-file=google_compute_engine

gcloud compute ssh ${MAPPER_NODE} --project=${PROJECT_ID} --zone=${ZONE} --ssh-key-file=google_compute_engine  --command "chmod +x *.sh"

gcloud compute ssh ${MAPPER_NODE} --project=${PROJECT_ID} --zone=${ZONE} --ssh-key-file=google_compute_engine --command "./bootstrap.sh -y"

sleep 2

gcloud compute ssh ${MAPPER_NODE} --project=${PROJECT_ID} --zone=${ZONE} --ssh-key-file=google_compute_engine  --command "nohup python3 mapper.py --mapper_id=${MAPPER_NODE} --master_addr=${MASTER_ADDR} --master_port=${MASTER_PORT} --kvstore_addr=${KV_ADDRESS} --kvstore_port=${KV_PORT}> ${MAPPER_NODE}.log 2>&1  </dev/null &"
