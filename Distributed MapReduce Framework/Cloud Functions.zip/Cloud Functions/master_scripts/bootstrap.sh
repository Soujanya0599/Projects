#sudo touch /var/lib/man-db/auto-update

sudo apt-get update -y

sudo apt install python3-pip -y

sudo pip3 install -r requirements.txt

sudo pip3 install --upgrade google-cloud-compute